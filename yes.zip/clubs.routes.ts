import { Router, Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { prisma } from '../config/database';
import { authenticate } from '../middleware/auth.middleware';
import { sendSuccess } from '../utils/response';

const router = Router();
router.use(authenticate);

const createClubSchema = z.object({
  name:            z.string().min(2).max(100),
  shortName:       z.string().min(2).max(8),
  city:            z.string().min(2).max(100),
  country:         z.string().min(2).max(100).default('Germany'),
  emblem:          z.string().max(10).default('⚽'),
  level:           z.number().int().min(1).max(100).default(1),
  plan:            z.enum(['BASIC','PRO','ACADEMY']).default('PRO'),
  managerName:     z.string().min(2).max(100),
  managerEmail:    z.string().email(),
  managerPassword: z.string().min(8).max(128),
  managerRole:     z.enum(['CLUB_ADMIN','HEAD_COACH','ANALYST','PHYSIO']).default('CLUB_ADMIN'),
});

router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const clubs = await prisma.club.findMany({
      where: { id: req.user!.clubId },
      select: {
        id:true, name:true, shortName:true, emblem:true,
        city:true, country:true, level:true, plan:true,
        overallRating:true, subscriptionStatus:true,
        _count: { select: { players:true } },
      },
    });
    return sendSuccess(res, clubs);
  } catch (err) { return next(err); }
});

router.post('/create', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const d = createClubSchema.parse(req.body);

    const existing = await prisma.user.findUnique({ where: { email: d.managerEmail.toLowerCase() } });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Email already in use' });
    }

    const club = await prisma.club.create({
      data: {
        name: d.name,
        shortName: d.shortName.toUpperCase(),
        emblem: d.emblem,
        city: d.city,
        country: d.country,
        level: d.level,
        plan: d.plan,
        overallRating: 80,
        subscriptionStatus: 'TRIALING',
        trialEndsAt: new Date(Date.now() + 14 * 86400000),
        currentPeriodEnd: new Date(Date.now() + 14 * 86400000),
      },
    });

    const nameParts = d.managerName.trim().split(' ');
    const pwHash = await bcrypt.hash(d.managerPassword, 12);
    const manager = await prisma.user.create({
      data: {
        email: d.managerEmail.toLowerCase(),
        passwordHash: pwHash,
        firstName: nameParts[0] || 'Manager',
        lastName: nameParts.slice(1).join(' ') || club.shortName,
        role: d.managerRole,
        clubId: club.id,
      },
    });

    return sendSuccess(res, {
      club: { id: club.id, name: club.name, shortName: club.shortName },
      manager: { id: manager.id, email: manager.email },
      loginCredentials: { email: d.managerEmail, password: d.managerPassword },
    }, 'Club created successfully', 201);

  } catch (err) { return next(err); }
});

export default router;
