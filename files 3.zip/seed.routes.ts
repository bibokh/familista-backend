// src/routes/seed.routes.ts
// One-time seed endpoint — disabled in production after first run
import { Router, Request, Response } from 'express';
import { prisma } from '../config/database';
import bcrypt from 'bcryptjs';
import { logger } from '../utils/logger';

const router = Router();

router.post('/run', async (req: Request, res: Response) => {
  const secret = req.headers['x-seed-secret'];
  if (secret !== process.env.SEED_SECRET && secret !== 'familista-seed-2024') {
    return res.status(403).json({ success: false, message: 'Forbidden' });
  }

  try {
    logger.info('Starting database seed...');

    // ── CLUB ──
    const club = await prisma.club.upsert({
      where: { id: 'fam-hsr-berlin-001' },
      update: { overallRating: 108.9, leaguePosition: 1 },
      create: {
        id: 'fam-hsr-berlin-001',
        name: 'Familista HSR',
        shortName: 'FHSR',
        emblem: '🔴',
        city: 'Berlin',
        country: 'Germany',
        founded: new Date('2023-10-15'),
        stadium: 'Herta Stadium Berlin',
        capacity: 32350,
        level: 33,
        overallRating: 108.9,
        leaguePosition: 1,
        fanClub: 'Familista Berlin',
        plan: 'ACADEMY',
        subscriptionStatus: 'ACTIVE',
        currentPeriodEnd: new Date('2025-12-31'),
      },
    });

    // ── USERS ──
    const adminHash = await bcrypt.hash('Familista2024!', 12);
    await prisma.user.upsert({
      where: { email: 'khatab@familista.io' },
      update: {},
      create: {
        email: 'khatab@familista.io',
        passwordHash: adminHash,
        firstName: 'Khatab',
        lastName: 'Atiya',
        role: 'CLUB_ADMIN',
        clubId: club.id,
      },
    });

    const coachHash = await bcrypt.hash('Coach2024!', 12);
    await prisma.user.upsert({
      where: { email: 'coach@familista.io' },
      update: {},
      create: {
        email: 'coach@familista.io',
        passwordHash: coachHash,
        firstName: 'Thomas',
        lastName: 'Mueller',
        role: 'HEAD_COACH',
        clubId: club.id,
      },
    });

    await prisma.user.upsert({
      where: { email: 'analyst@familista.io' },
      update: {},
      create: {
        email: 'analyst@familista.io',
        passwordHash: await bcrypt.hash('Analyst2024!', 12),
        firstName: 'Sarah',
        lastName: 'Wagner',
        role: 'ANALYST',
        clubId: club.id,
      },
    });

    // ── PLAYERS ──
    const playerDefs = [
      { fn:'Pavel', ln:'Barkov', num:1, pos:'GK', nat:'Russia', flag:'🇷🇺', dob:'1996-03-12', h:188, w:84, ovr:109, pot:114, cnd:95, mv:26208000, wage:196 },
      { fn:'Daan', ln:'de Meijer', num:2, pos:'DC', nat:'Netherlands', flag:'🇳🇱', dob:'1998-07-21', h:184, w:82, ovr:110, pot:116, cnd:88, mv:26400000, wage:198 },
      { fn:'Juan', ln:'Caceres', num:5, pos:'DC', nat:'Argentina', flag:'🇦🇷', dob:'1995-11-03', h:181, w:78, ovr:99, pot:103, cnd:72, mv:23760000, wage:178 },
      { fn:'Ramzi', ln:'Jebali', num:6, pos:'DC', nat:'Tunisia', flag:'🇹🇳', dob:'1999-05-18', h:183, w:80, ovr:103, pot:108, cnd:90, mv:24720000, wage:185 },
      { fn:'Tobias', ln:'Schroden', num:23, pos:'DMC', nat:'Germany', flag:'🇩🇪', dob:'2000-02-14', h:180, w:75, ovr:121, pot:128, cnd:68, mv:29040000, wage:218 },
      { fn:'David', ln:'Grahl', num:8, pos:'ML', nat:'Germany', flag:'🇩🇪', dob:'1997-09-27', h:177, w:72, ovr:109, pot:113, cnd:86, mv:26160000, wage:196 },
      { fn:'Tim', ln:'Hanke', num:4, pos:'MC', nat:'Germany', flag:'🇩🇪', dob:'2001-06-08', h:179, w:74, ovr:98, pot:106, cnd:92, mv:23520000, wage:176 },
      { fn:'Ahmed', ln:'Kabar', num:14, pos:'MC', nat:'Germany', flag:'🇩🇪', dob:'1999-12-01', h:180, w:76, ovr:123, pot:130, cnd:95, mv:29520000, wage:222 },
      { fn:'Oliver', ln:'Frings', num:15, pos:'MR', nat:'Germany', flag:'🇩🇪', dob:'1998-04-22', h:176, w:71, ovr:124, pot:130, cnd:94, mv:29760000, wage:224 },
      { fn:'Christopher', ln:'Lowens', num:11, pos:'AMC', nat:'Germany', flag:'🇩🇪', dob:'2000-08-15', h:174, w:70, ovr:99, pot:108, cnd:88, mv:23760000, wage:178 },
      { fn:'Naoki', ln:'Fujita', num:20, pos:'ST', nat:'Japan', flag:'🇯🇵', dob:'2002-01-30', h:172, w:68, ovr:96, pot:104, cnd:82, mv:23040000, wage:172 },
    ];

    const players = [];
    for (const p of playerDefs) {
      const player = await prisma.player.upsert({
        where: { id: `player-${p.num}-fhsr` },
        update: { condition: p.cnd },
        create: {
          id: `player-${p.num}-fhsr`,
          firstName: p.fn,
          lastName: p.ln,
          number: p.num,
          position: p.pos as never,
          nationality: p.nat,
          flag: p.flag,
          dateOfBirth: new Date(p.dob),
          height: p.h,
          weight: p.w,
          overallRating: p.ovr,
          potential: p.pot,
          condition: p.cnd,
          marketValue: p.mv,
          weeklyWage: p.wage,
          preferredFoot: 'RIGHT',
          contractUntil: new Date('2026-12-31'),
          clubId: club.id,
        },
      });

      // GPS data — 7 sessions
      for (let i = 0; i < 7; i++) {
        const daysAgo = i * 2;
        const baseSpeed = 20 + Math.random() * 14;
        await prisma.playerGpsData.create({
          data: {
            playerId: player.id,
            sessionType: i % 3 === 0 ? 'match' : 'training',
            topSpeed: parseFloat(baseSpeed.toFixed(1)),
            avgSpeed: parseFloat((baseSpeed * 0.45).toFixed(1)),
            distance: parseFloat((8 + Math.random() * 5).toFixed(2)),
            sprintCount: Math.floor(8 + Math.random() * 20),
            heartRateAvg: Math.floor(155 + Math.random() * 25),
            heartRateMax: Math.floor(185 + Math.random() * 12),
            playerLoad: parseFloat((80 + Math.random() * 60).toFixed(1)),
            riskScore: parseFloat((Math.random() * 80).toFixed(1)),
            recordedAt: new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000),
          },
        });
      }

      // GPS Device
      await prisma.gpsDevice.upsert({
        where: { serialNumber: `FAM-${player.id.toUpperCase()}-2025` },
        update: { isOnline: true, batteryLevel: 85 },
        create: {
          serialNumber: `FAM-${player.id.toUpperCase()}-2025`,
          firmware: 'v1.2',
          isOnline: true,
          batteryLevel: 85,
          signalQuality: 100,
          clubId: club.id,
          playerId: player.id,
          lastSeenAt: new Date(),
        },
      });

      players.push(player);
    }

    // ── INJURIES ──
    await prisma.playerInjury.upsert({
      where: { id: 'inj-caceres-001' },
      update: {},
      create: {
        id: 'inj-caceres-001',
        playerId: 'player-5-fhsr',
        bodyPart: 'Hamstring',
        injuryType: 'Hamstring Strain Grade II',
        severity: 'CRITICAL',
        injuredAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        expectedReturn: new Date(Date.now() + 11 * 24 * 60 * 60 * 1000),
        notes: 'GPS load spike detected 48h before injury. Recommend load monitoring protocol.',
      },
    });
    await prisma.player.update({ where: { id: 'player-5-fhsr' }, data: { isInjured: true } });

    await prisma.playerInjury.upsert({
      where: { id: 'inj-schroden-001' },
      update: {},
      create: {
        id: 'inj-schroden-001',
        playerId: 'player-23-fhsr',
        bodyPart: 'General',
        injuryType: 'Fatigue Overload',
        severity: 'MODERATE',
        injuredAt: new Date(),
        expectedReturn: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        notes: 'Player load exceeded 140 units. Rest protocol initiated.',
      },
    });

    await prisma.playerInjury.upsert({
      where: { id: 'inj-fujita-001' },
      update: {},
      create: {
        id: 'inj-fujita-001',
        playerId: 'player-20-fhsr',
        bodyPart: 'Ankle',
        injuryType: 'Lateral Ankle Sprain',
        severity: 'MINOR',
        injuredAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        expectedReturn: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
        notes: 'Rolled ankle during training. Ice and compression applied.',
      },
    });

    // ── MATCHES ──
    const matchData = [
      { ht:'Familista HSR', at:'KawasakiFrontale', hs:4, as:1, r:'WIN', comp:'LEAGUE', daysAgo:3, poss:62, shots:18, sot:9 },
      { ht:'Familista HSR', at:'Manchester City', hs:7, as:0, r:'WIN', comp:'ELITE', daysAgo:4, poss:58, shots:22, sot:14 },
      { ht:'สโมสร 44945', at:'Familista HSR', hs:2, as:1, r:'LOSS', comp:'CUP', daysAgo:5, poss:44, shots:12, sot:5 },
      { ht:'Familista HSR', at:'Pandawa Fc', hs:5, as:0, r:'WIN', comp:'ELITE', daysAgo:6, poss:67, shots:20, sot:12 },
      { ht:'Familista HSR', at:'Cozea FC', hs:3, as:2, r:'WIN', comp:'LEAGUE', daysAgo:7, poss:55, shots:16, sot:8 },
      { ht:'AEK Athens', at:'Familista HSR', hs:1, as:4, r:'WIN', comp:'ELITE', daysAgo:9, poss:49, shots:14, sot:7 },
      { ht:'Familista HSR', at:'Atletico Madrid', hs:6, as:0, r:'WIN', comp:'LEAGUE', daysAgo:11, poss:61, shots:19, sot:11 },
      { ht:'Sporting CP', at:'Familista HSR', hs:2, as:2, r:'DRAW', comp:'LEAGUE', daysAgo:14, poss:52, shots:13, sot:6 },
    ];

    for (let i = 0; i < matchData.length; i++) {
      const m = matchData[i];
      const scheduledAt = new Date(Date.now() - m.daysAgo * 24 * 60 * 60 * 1000);
      const match = await prisma.match.upsert({
        where: { id: `match-${i + 1}-fhsr` },
        update: {},
        create: {
          id: `match-${i + 1}-fhsr`,
          clubId: club.id,
          homeTeam: m.ht,
          awayTeam: m.at,
          homeScore: m.hs,
          awayScore: m.as,
          result: m.r as never,
          isHome: m.ht.includes('Familista'),
          competition: m.comp as never,
          scheduledAt,
          playedAt: scheduledAt,
          possession: m.poss,
          shots: m.shots,
          shotsOnTarget: m.sot,
          corners: Math.floor(4 + Math.random() * 8),
          fouls: Math.floor(8 + Math.random() * 10),
          yellowCards: Math.floor(Math.random() * 3),
        },
      });

      // Player match stats
      for (const player of players) {
        const isAttacker = ['ST', 'AMC', 'MR', 'ML'].includes(player.position);
        await prisma.playerMatchStat.upsert({
          where: { matchId_playerId: { matchId: match.id, playerId: player.id } },
          update: {},
          create: {
            matchId: match.id,
            playerId: player.id,
            minutesPlayed: Math.random() > 0.1 ? 90 : Math.floor(45 + Math.random() * 45),
            goals: isAttacker ? (Math.random() > 0.6 ? 1 : 0) : 0,
            assists: Math.random() > 0.7 ? 1 : 0,
            shots: Math.floor(Math.random() * 5),
            passes: Math.floor(30 + Math.random() * 50),
            passAccuracy: parseFloat((72 + Math.random() * 22).toFixed(1)),
            tackles: Math.floor(Math.random() * 6),
            rating: parseFloat((6 + Math.random() * 3.5).toFixed(1)),
          },
        });
      }
    }

    // Upcoming match
    await prisma.match.upsert({
      where: { id: 'match-next-fhsr' },
      update: {},
      create: {
        id: 'match-next-fhsr',
        clubId: club.id,
        homeTeam: 'Analytics Utd',
        awayTeam: 'Familista HSR',
        isHome: false,
        competition: 'LEAGUE',
        scheduledAt: new Date(new Date().setHours(14, 30, 0, 0)),
        venue: 'Herta Stadium, Berlin',
      },
    });

    // ── TOURNAMENTS ──
    const tourns = [
      { id:'tourn-l33', name:'League Level 33', type:'LEAGUE', teams:14, pos:1, pts:21, w:7, d:0, l:0, gf:34, ga:2 },
      { id:'tourn-el', name:'Elite League', type:'ELITE', teams:14, pos:4, pts:21, w:7, d:0, l:0, gf:28, ga:12 },
      { id:'tourn-cup', name:'Cup Season 207', type:'CUP', teams:64, pos:null, pts:null, w:2, d:0, l:1, gf:7, ga:2 },
      { id:'tourn-asso', name:'Association Tournament', type:'ASSOCIATION', teams:8, pos:1, pts:12, w:4, d:0, l:0, gf:22, ga:5 },
    ];
    for (const t of tourns) {
      await prisma.tournament.upsert({
        where: { id: t.id },
        update: {},
        create: { ...t, clubId: club.id, played: t.w + t.d + t.l } as never,
      });
    }

    // ── TRAINING SESSIONS ──
    const trainingData = [
      { title:'Pre-match Activation', duration:60, drills:['SPRINT_INTERVALS', 'TECHNICAL_PASSING'], daysAgo:1 },
      { title:'Tactical Shape Work', duration:90, drills:['DEFENSIVE_SHAPE', 'POSSESSION'], daysAgo:3 },
      { title:'High Intensity Block', duration:75, drills:['SPRINT_INTERVALS', 'PRESSING'], daysAgo:5 },
      { title:'Recovery & Mobility', duration:45, drills:['RECOVERY'], daysAgo:7 },
      { title:'Set Piece Training', duration:80, drills:['SET_PIECES', 'SHOOTING_PRACTICE'], daysAgo:9 },
    ];

    for (let i = 0; i < trainingData.length; i++) {
      const t = trainingData[i];
      const session = await prisma.trainingSession.upsert({
        where: { id: `training-${i + 1}-fhsr` },
        update: {},
        create: {
          id: `training-${i + 1}-fhsr`,
          clubId: club.id,
          title: t.title,
          duration: t.duration,
          drills: t.drills as never,
          scheduledAt: new Date(Date.now() - t.daysAgo * 24 * 60 * 60 * 1000),
          attackForm: Math.floor(12 + Math.random() * 4),
          defenseForm: Math.floor(13 + Math.random() * 3),
          possession: Math.floor(10 + Math.random() * 5),
          conditionForm: Math.floor(11 + Math.random() * 5),
        },
      });

      for (const player of players) {
        await prisma.playerTrainingStat.upsert({
          where: { sessionId_playerId: { sessionId: session.id, playerId: player.id } },
          update: {},
          create: {
            sessionId: session.id,
            playerId: player.id,
            attended: Math.random() > 0.1,
            rating: parseFloat((6 + Math.random() * 3.5).toFixed(1)),
          },
        });
      }
    }

    // ── SCOUT REPORTS ──
    const scouts = [
      { n:'Marco Rodriguez', c:'FC Valencia', pos:'DMC', age:24, nat:'Spain', flag:'🇪🇸', mv:2100000, r:4.0, rec:'SIGN', notes:'94% pass completion under pressure. Perfect pressing profile.' },
      { n:'Bartosz Kowalski', c:'Lech Poznan', pos:'DC', age:22, nat:'Poland', flag:'🇵🇱', mv:1400000, r:3.5, rec:'SIGN', notes:'Strong aerial ability. 78% duel success rate.' },
      { n:'Yuto Tanaka', c:'Gamba Osaka', pos:'MC', age:25, nat:'Japan', flag:'🇯🇵', mv:3200000, r:4.0, rec:'MONITOR', notes:'Box-to-box quality. Needs adaptation to European pace.' },
      { n:'Lucas Santos', c:'Benfica B', pos:'ST', age:21, nat:'Brazil', flag:'🇧🇷', mv:4800000, r:4.5, rec:'MONITOR', notes:'Elite finishing. 0.68 xG per 90. Potential star signing.' },
      { n:'Kevin Müller', c:'Schalke 04', pos:'GK', age:23, nat:'Germany', flag:'🇩🇪', mv:1800000, r:3.5, rec:'SKIP', notes:'Inconsistent shot-stopping. Not recommended at current level.' },
      { n:'Ahmed Ibrahim', c:'Al Ahly', pos:'ML', age:26, nat:'Egypt', flag:'🇪🇬', mv:2600000, r:4.0, rec:'SIGN', notes:'Exceptional crossing. 8.2 progressive carries per 90.' },
    ];

    for (let i = 0; i < scouts.length; i++) {
      const s = scouts[i];
      await prisma.scoutReport.upsert({
        where: { id: `scout-${i + 1}-fhsr` },
        update: {},
        create: {
          id: `scout-${i + 1}-fhsr`,
          clubId: club.id,
          targetName: s.n,
          targetClub: s.c,
          position: s.pos as never,
          age: s.age,
          nationality: s.nat,
          flag: s.flag,
          marketValue: s.mv,
          rating: s.r,
          recommendation: s.rec as never,
          notes: s.notes,
        },
      });
    }

    // ── FINANCIALS ──
    const fins = [
      { t:'INCOME', cat:'Investment', amt:26000000, desc:'Season investment round' },
      { t:'INCOME', cat:'Ticket Sales', amt:26800000, desc:'Home matches revenue' },
      { t:'INCOME', cat:'Sponsorship', amt:130000000, desc:'JUICE + OH₂ sponsorship deals' },
      { t:'INCOME', cat:'Prize Money', amt:5200000, desc:'League position bonus' },
      { t:'INCOME', cat:'Transfers Income', amt:0, desc:'No sales this window' },
      { t:'EXPENSE', cat:'Player Wages', amt:63400000, desc:'Monthly player salaries' },
      { t:'EXPENSE', cat:'Staff Wages', amt:8200000, desc:'Coaching + medical staff' },
      { t:'EXPENSE', cat:'Facilities', amt:2000000, desc:'Training ground maintenance' },
      { t:'EXPENSE', cat:'Travel', amt:1500000, desc:'Away match logistics' },
      { t:'EXPENSE', cat:'Medical', amt:800000, desc:'Medical equipment + staff' },
    ];

    for (let i = 0; i < fins.length; i++) {
      const f = fins[i];
      await prisma.financial.upsert({
        where: { id: `fin-${i + 1}-fhsr` },
        update: {},
        create: {
          id: `fin-${i + 1}-fhsr`,
          clubId: club.id,
          type: f.t as never,
          category: f.cat,
          amount: f.amt,
          description: f.desc,
          date: new Date(),
        },
      });
    }

    logger.info('Seed completed successfully');

    return res.json({
      success: true,
      message: '🎉 Database seeded successfully!',
      data: {
        club: club.name,
        players: players.length,
        matches: matchData.length + 1,
        tournaments: tourns.length,
        trainingSessions: trainingData.length,
        scoutReports: scouts.length,
        financials: fins.length,
        credentials: {
          admin: 'khatab@familista.io / Familista2024!',
          coach: 'coach@familista.io / Coach2024!',
          analyst: 'analyst@familista.io / Analyst2024!',
        },
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    logger.error('Seed failed', { err });
    return res.status(500).json({ success: false, message, error: String(err) });
  }
});

export default router;
